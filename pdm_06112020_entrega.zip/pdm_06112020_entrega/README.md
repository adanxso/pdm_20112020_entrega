# dispositos-mobile

Aplicação mobile feita em [React Native](https://reactnative.dev/)

## Desenvolvimento

* Renomeie o arquivo `env.js.example` para `env.js`

* Customize as variáveis de ambiente com as informações necessárias

* Iniciar a aplicação

    ```bash
    yarn start
    ```

* Expo developer tools disponível em [localhost:19002](http://localhost:19002/)
